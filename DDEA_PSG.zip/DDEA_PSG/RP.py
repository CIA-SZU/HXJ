

def getRP(yp, yt):
    n = yp.shape[0]
    count = 0
    for i in range(0, n):
        for j in range(i + 1, n):
            if (yp[i] < yp[j] and yt[i] < yt[j]) or (yp[i] > yp[j] and yt[i] > yt[j]) or (yp[i] == yp[j] and yt[i] == yt[j]):
                count = count + 1
    return count / (n * (n - 1) / 2)

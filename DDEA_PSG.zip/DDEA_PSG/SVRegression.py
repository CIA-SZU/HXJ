import sklearn.svm as svm
import RP
import matplotlib.pyplot as plt
import numpy as np


class SVR:

    def __init__(self, kernel='rbf', degree=3, c=9000):
        self.model = svm.SVR(kernel=kernel, degree=degree, C=c)

    def fit(self, x, y):
        self.model.fit(x, y.ravel())

    def predict(self, x):
        return self.model.predict(x)


    def getRP(self, x, y):
        yp = self.predict(x)
        return RP.getRP(yp, y)

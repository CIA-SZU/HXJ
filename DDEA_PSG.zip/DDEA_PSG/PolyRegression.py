from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
import numpy as np
import matplotlib.pyplot as plt
import RP


class PR:

    def __init__(self, degree=2):
        self.poly = PolynomialFeatures(degree)
        self.regression = LinearRegression()

    def fit(self, x, y):
        self.regression.fit(self.poly.fit_transform(x), y)

    def predict(self, x):
        return self.regression.predict(self.poly.fit_transform(x))

    def getRP(self, x, y):
        yp = self.predict(x)
        return RP.getRP(yp, y)

from sklearn.model_selection import KFold
import sklearn.linear_model as lm
from sklearn.linear_model import Ridge
from sklearn.linear_model import Lasso
import numpy as np
from PolyRegression import PR
from SVRegression import SVR
from RBNetworks import RBNN
import matplotlib.pyplot as plt

import RP
import math

dim = 10
#print('dim = ', dim)
c = int(math.sqrt(dim))
nc = c

#surrogate parameters
svr = {
    'kernel': 'rbf',
    'degree': 3,
    'c': 50000
}

pr = {
    'degree': 2
}

rbnn1 = {
    'k': nc,
    'rbf': 'gaussian_rbf1',
    'inferStds': False
}

rbnn2 = {
    'k': nc,
    'rbf': 'gaussian_rbf2',
    'inferStds': False
}

rbnn3 = {
    'k': nc,
    'rbf': 'reflect_sigmoid_rbf',
    'inferStds': False
}

rbnn4 = {
    'k': nc,
    'rbf': 'inverse_multiquadric_rbf',
    'inferStds': False
}

rbnn5 = {
    'k': nc,
    'rbf': 'multiquadric_rbf',
    'inferStds': False
}


class LearnerHelper(object):
    def __init__(self, model, seed=0, params=None):
        #params['random_state'] = seed
        self.model = model(**params)

    def train(self, x_train, y_train):
        self.model.fit(x_train, y_train)

    def predict(self, x):
        return self.model.predict(x)

    def fit(self, x, y):
        return self.model.fit(x, y)

    def feature_importances(self, x, y):
        print(self.model.fit(x, y).feature_importances_)

    def getRP(self, x, y):
        return self.model.getRP(x, y)


class SelectiveStacking:

    def __init__(self, seed=0, n_fold=6):
        self.n_fold = n_fold
        self.seed = seed
        #base learner
        self.base_learner_opt = [{'reg': RBNN, 'seed': seed, 'params': rbnn2},
                                 {'reg': PR, 'seed': seed, 'params': pr},
                                 {'reg': SVR, 'seed': seed, 'params': svr}]
        self.all_base_learner = []
        self.RP_values = []
        self.test_indexs = []
        #meta learner
        #self.meta_model = lm.LinearRegression()
        self.meta_model = Ridge(alpha=0.7)
        #self.meta_model = Lasso(alpha=0.7)

    def get_oof(self,  x, y_train=None, x_test=None, y_test=None, test=False, k=-1):
        oof_feature = np.zeros((x_test.shape[0], len(self.base_learner_opt)))
        rp = 0
        for i, learner_opt in enumerate(self.base_learner_opt):
            # if test:
            #     oof_feature_test[:, i] += self.all_base_learner[k * self.n_fold + i].predict(x).reshape(-1, 1)
            clf = LearnerHelper(model=learner_opt['reg'], seed=learner_opt['seed'], params=learner_opt['params'])
            clf.train(x, y_train)
            self.all_base_learner.append(clf)
            rp += clf.getRP(x_test, y_test)
            oof_feature[:, [i]] = clf.predict(x_test).reshape(-1, 1)
        self.RP_values.append(rp)

        return oof_feature

    def get_tf(self, x, learner_index):
        tf_feature = np.zeros((x.shape[0], len(self.model_index)))
        for i in range(len(self.model_index)):
            tf_feature[:, [i]] = self.all_base_learner[self.model_index[i] * len(self.base_learner_opt) + learner_index].predict(x).reshape(-1, 1)
        tf_feature = tf_feature.mean(axis=1)
        return tf_feature

    def modelSelection(self, rate=0.5):
        sort_index = np.argsort(self.RP_values)[::-1]
        model_num = int(rate * self.n_fold)
        self.model_index = sort_index[:model_num]


    def fit(self, x, y):

        x_train = np.empty((x.shape[0], len(self.base_learner_opt)))
        # for i, learner_opt in enumerate(self.base_learner_opt):
        #     train = self.get_oof(x, y, learner_opt=learner_opt, test=False, learner_index=i)
        #     x_train[:, [i]] = train
        kf = KFold(n_splits=self.n_fold, shuffle=True, random_state=self.seed)
        kf_split = kf.split(x)
        for i, (train_index, test_index) in enumerate(kf_split):
            # test_indexes of k sets
            self.test_indexs.append(test_index)
            train = self.get_oof(x[train_index], y[train_index], x[test_index], y[test_index])
            x_train[test_index, :] = train
        self.meta_model.fit(x_train, y)
        #print(self.meta_model.coef_.tolist())

    def predict(self, x):
        x_test = np.zeros((x.shape[0], len(self.base_learner_opt)))
        for i, learner_opt in enumerate(self.base_learner_opt):
            test = self.get_tf(x, learner_index=i)
            x_test[:, [i]] = test.reshape(-1, 1)
        return self.meta_model.predict(x_test)

    def getRMSE(self, x, y):
        yp = self.predict(x)
        xl = list(range(x.shape[0]))
        plt.plot(xl, y, color='red')
        plt.plot(xl, yp, color='blue')
        plt.show()
        rmse = np.sqrt(((yp - y) ** 2).mean())
        return rmse

    def getRP(self, x, y):
        yp = self.predict(x)
        return RP.getRP(yp, y)




from pymoo.factory import get_sampling, get_crossover, get_mutation
from pymoo.interface import sample, crossover, mutation

import numpy as np
import random
import time
import math
from SelectiveStacking import SelectiveStacking


def initialize(ni, c, lb, ub):
    sampling_opt = get_sampling('real_lhs')
    pop = sample(sampling_opt, ni, c, lb, ub)
    return pop


def SBX(pop, ub, lb, pc, eta_c=15):
    N = pop.shape[0]
    c = pop.shape[1]
    npop = []
    crossover_opt = get_crossover('real_sbx', prob=pc, eta=eta_c, prob_per_variable=1.0)
    for i in range(0, N):
        if random.random() < pc:
            A = np.random.permutation(N)
            if A[0] < A[1]:
                y = A[0]
            else:
                y = A[1]
            if y == i:
                y = A[2]

            if ~((pop[y] == pop[i]).all()):
                tpop = crossover(crossover_opt, a=pop[i].reshape(-1, 1), b=pop[y]. reshape(-1, 1), xl=lb, xu=ub, type_var=np.double)
                npop.append(tpop[0:c])
                npop.append(tpop[c:2*c])

    return np.array(npop).reshape(-1, c)


def PolyMutation(pop, ub, lb, pm, eta_c=15):
    mutation_opt = get_mutation("real_pm", eta=eta_c, prob=pm)
    npop = mutation(mutation_opt, pop, xl=lb, xu=ub)
    return np.array(npop)

def TrueEvaluation(P, x, c):
    x = x.reshape(-1, c)
    if P == 'Ellipsoid':
        t = np.array(range(1, c+1)).reshape(1, -1)
        t = np.dot(np.ones((x.shape[0], 1)), t)
        t = np.multiply(t, np.multiply(x, x))
        FE = t.sum(axis=1)
    elif P == 'Rosenbrock':
        t = 100 * np.square((x[:, 1:c] - np.square(x[:, 0:c - 1]))) + np.square(x[:, 0:c - 1] - 1)
        FE = t.sum(axis=1)
    elif P == 'Ackley':
        t1 = np.mean(np.multiply(x, x), axis=1)
        t2 = np.mean(np.cos(2 * np.pi * x), axis=1)
        FE = 20 - 20 * np.exp(-0.2 * np.sqrt(t1)) - np.exp(t2) + np.exp(1)
    elif P == 'Griewank':
        t = np.array(range(1, c+1)).reshape(1, -1)
        t = np.sqrt(t)
        t = np.dot(np.ones((x.shape[0], 1)), t)
        FE = np.sum(np.multiply(x, x), axis=1) / 4000 + 1 - np.prod(np.cos(np.divide(x, t)), axis=1)
    elif P == 'Rastrigin':
        t = np.square(x[:, 0:c]) - 10 * np.cos(2 * math.pi * x[:, 0:c])
        FE = 10 * c + t.sum(axis=1)
    return FE.reshape(-1, 1)


def DDEA(c, D, lb, ub):
    random.seed()


    TDx = D[:, 0:c]
    TDy = D[:, c]
    TDy = TDy.reshape(-1, 1)
    #train surrogate
    model = SelectiveStacking(n_fold=30)
    model.fit(TDx, TDy)
    model.modelSelection(rate=0.6)

    n = 100     # population Size
    pc = 1      # Crossover Probability
    eta_c = 15
    pm = 1/c    # Mutation Probability
    gmax = 100  # Max Generation

    gbest = []

    pop = initialize(n, c, lb, ub)

    for i in range(0, gmax):
        #mating
        npop1 = SBX(pop, ub, lb, pc, eta_c)
        npop2 = PolyMutation(npop1, ub, lb, pm, eta_c)
        pop = np.concatenate((pop, npop2), axis=0)
        #evaluation
        Y = model.predict(pop).reshape(-1, 1)
        pop = np.concatenate((pop, Y), axis=1)
        #selection
        tpop = pop[pop[:, c].argsort()]
        pop = tpop[0:n, 0:c]
        gbest.append(tpop[0, :])

    return np.array(gbest).reshape(-1, c + 1)


if __name__ == '__main__':
    dim = 10
    lb = -5.12
    ub = 5.12
    problem = 'Ellipsoid'
    x = initialize(11 * dim, dim, lb, ub)
    y = TrueEvaluation(problem, x, dim)
    data = np.concatenate((x, y), axis=1)
    starttime = time.time()
    gb = DDEA(dim, data, lb, ub)
    endtime = time.time()
    print('Runtime: ', endtime - starttime)



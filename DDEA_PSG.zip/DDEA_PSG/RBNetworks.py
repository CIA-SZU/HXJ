import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
from scipy.linalg import norm, pinv
import RP


def gaussian_rbf1(x, c, s):
    return np.exp(-1 / (s ** 2) * np.linalg.norm(x - c) ** 2)


def gaussian_rbf2(x, c, s):
    return np.exp(-1 / (2 * s ** 2) * np.linalg.norm(x - c) ** 2)


def reflect_sigmoid_rbf(x, c, s):
    return 1 / (1 + np.exp(np.linalg.norm(x - c) ** 2 / s ** 2))


def inverse_multiquadric_rbf(x, c, s):
    return 1 / np.sqrt(np.linalg.norm(x - c) ** 2 + s ** 2)


def multiquadric_rbf(x, c, s):
    return 1 / (np.linalg.norm(x - c) ** 2 + s ** 2)


rbf_dict = {
    'gaussian_rbf1': gaussian_rbf1,
    'gaussian_rbf2': gaussian_rbf2,
    'reflect_sigmoid_rbf': reflect_sigmoid_rbf,
    'inverse_multiquadric_rbf': inverse_multiquadric_rbf,
    'multiquadric_rbf': multiquadric_rbf
}
def getC_S(x, class_num):
    estimator = KMeans(n_clusters=class_num, max_iter=5000)
    estimator.fit(x)
    c = estimator.cluster_centers_
    n = len(c)
    Cmax = 0
    for i in range(n):
        j = i + 1
        while j < n:
            t = np.sum((c[i] - c[j]) ** 2)
            Cmax = max(Cmax, t)
            j = j + 1

    s = np.sqrt(Cmax) / np.sqrt(2 * n)
    #print(c, type(c), '\n', s, type(s))
    return c, s


def getSpread(self):
    sum = 0
    count = 0
    for i in range(self.k - 1):
        for j in range(i + 1, self.k):
            sum += np.linalg.norm(self.centers[j] - self.centers[i])
            count += 1
    return 2 * sum / count


class RBNN:
    def __init__(self, k=2, lr=0.0035, epochs=300, rbf='gaussian_rbf1', inferStds=False):
        self.k = k
        self.lr = lr
        self.epochs = epochs
        self.rbf = rbf_dict[rbf]      #高斯径向基函数
        self.inferStds = inferStds

        self.w = np.random.randn(k)
        self.b = np.random.randn(1)

    ##
    def getSpread(self):
        sum = 0
        count = 0
        for i in range(self.k - 1):
            for j in range(i + 1, self.k):
                sum += np.linalg.norm(self.centers[j] - self.centers[i])
                count += 1
        return sum / count

    def fit(self, X, y):
        if self.inferStds:
            # compute stds from data
            self.centers, stds = getC_S(X, self.k)
            self.stds = np.repeat(stds, self.k)
        else:
            # use a fixed std
            self.centers, _ = getC_S(X, self.k)

            stds = self.getSpread()
            self.stds = np.repeat(stds, self.k)


        rm = []
        for i in range(X.shape[0]):
            rv = np.array([self.rbf(X[i], c, s) for c, s in zip(self.centers, self.stds)])
            rm.append(rv)

        rm = np.array(rm).reshape(-1, self.k)
        rm = np.concatenate((rm, np.ones((X.shape[0], 1))), axis=1)
        t = np.dot(pinv(rm), y)
        self.w = t[0:self.k]
        self.b = t[self.k]

    def predict(self, X):
        y_pred = []
        for i in range(X.shape[0]):
            a = np.array([self.rbf(X[i], c, s) for c, s, in zip(self.centers, self.stds)])
            F = a.T.dot(self.w) + self.b
            y_pred.append(F)
        return np.array(y_pred)

    def getRP(self, x, y):
        yp = self.predict(x)
        return RP.getRP(yp, y)



